import './App.css';
import Starter from './components/starter/Starter';
import {
  BrowserRouter as Router,
 Routes,
  Route,
  Link
} from "react-router-dom";
import HomePage from './components/homePage/HomePage';

function App() {
  return (
    <Router>
    <Routes>
      <Route path="/" element={<Starter/>} />
      <Route path="/Home" element={<HomePage/>} />
    </Routes>
    </Router>
  );
}

export default App;

