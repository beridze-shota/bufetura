import React from 'react'
import styled from 'styled-components'

const BfButton1 = (props) => {
  return (
  <BfButton margin={props.margin}>{props.text}</BfButton>
  )
}


const BfButton = styled.button`
max-width: 425px;
font-weight: 700;
font-size: 25px;
margin:${(props) => props.margin ?? "0px"};
line-height: 29px;
text-align: center;
color: #FEFEFE;
height: 70px;
width: 100%;
   background: rgba(255, 255, 255, 0.21);
border: 1px solid #FFFFFF;
border-radius: 30px;
`

export default BfButton1