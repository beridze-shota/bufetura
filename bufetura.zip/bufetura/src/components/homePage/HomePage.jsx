import React from 'react'
import { HomePageWrapper, FoodBox } from '../starter/starter.Style'
import './HomePages.css'


const describes = {
    firstName: "შოთა ბერიძე",   
}
const food = ["1 ბურგერი",
              "2 კოკა-კოლა",
              "1 წყალი",
              "2 ფანქეიქი"]

const confirm = {
    confirmText : "დადასტურება"
}

const HomePage = () => {
  return (
    <div>
      <HomePageWrapper>
        <FoodBox>
            <h1 className='describe'>{describes.firstName}</h1>
            {food.map((food) => (
                <ul className="food">
                    <li>{food}</li>
                </ul>
             ))}
             <button type="button" class="btn btn-danger">{confirm.confirmText}</button>
        </FoodBox>
      </HomePageWrapper>
    </div>
  )
}

export default HomePage
